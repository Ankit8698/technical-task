<!DOCTYPE html>
<html>
<head>
    <title>Product Form</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  </head>
<body>

    <div class="container">
        <div class='text-right'>
            <a href='<?=base_url()?>product/records' class='btn btn-secondary float-end mt-5'>View records</a>
        </div>

        <div class='mt-2 mb-4 p-3 border'>
            <form method="post"  action="<?php echo base_url('product/submit_form'); ?>" id="productForm" class="needs-validation" novalidate >
                <div class='row mb-1 pl-3 pt-2'>
                    <div class='col-md-6 border rounded p-3 bg-light'>
                        <h4 class='text-center'>User Form</h4>
                        <hr>
                        <div class="form-group m-0">
                            <label for="name">Name:</label>
                            <input type="text" class="form-control" id="name" name="name" placeholder='Enter your name' value='<?=set_value('name');?>' required>

                        </div>

                        <div class="form-group m-0">
                            <label for="name">Username:</label>
                            <input type="text" class="form-control" id="username" name="username" placeholder='Enter username' value='<?=set_value('username');?>' required>
                      
                        </div>

                        <div class="form-group m-0">
                            <label for="name">Phone Number:</label>
                            <input type="number" class="form-control" id="mobile" name="mobile" placeholder='Enter your mobile number' value='<?=set_value('mobile');?>' required>
                       
                        </div>

                        <div class="form-group m-0">
                            <label for="name">Email Address:</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder='Enter your email address' value='<?=set_value('email');?>' required>
                      
                        </div>

                        <div class="form-group m-0">
                            <label for="name">Password</label>
                            <input type="password" class="form-control" id="password" name="password" placeholder='Enter password' value='<?=set_value('password');?>' required>
                        
                        </div>
                    </div>
                </div>
            

                <!-- Add other form fields as per your requirements -->
                <button type="button" class="btn btn-primary float-right mb-2" onclick="addRow()">Add</button>

                <table class="table mt-4 border" id="productTable">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Product Price</th>
                            <th>Product Quantity</th>
                            <th>Product Type</th>
                            <th>Discount</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                
                        <tr id="initialRow">
                            <td>
                                <input type="text" class="form-control" name="productName[]" placeholder="Product name"  id="validationCustom01" required>
                            </td>
                            <td>
                                <input type="number" class="form-control" step="0.01" name="productPrice[]" placeholder="Product price" required>
                            </td>
                            <td>
                                <input type="number" class="form-control" name="productQuantity[]" placeholder="Product quantity" required>
                            </td>
                            <td>
                                <select class="form-control" name="productType[]" required> 
                                    <option selected disabled value="">Choose...</option>
                                    <option value="flat">Flat</option>
                                    <option value="discount">Discount</option>
                                </select>
                            </td>
                            <td><input type="text" class="form-control" name="productDiscount[]" readonly placeholder="Add discount" required></td>
                        </tr>
                    </tbody>
                </table>

                <div class='row justify-content-end mt-4'>
                    <div class='col-md-4  '> 
                        <label for="finalAmount">Final Amount:</label>
                        <input type="text" class="form-control" id="finalAmount" name="finalAmount" readonly>

                    </div>
                </div>
                <div class="text-right">
                    <button type="submit" class="btn btn-success mt-3 mb-4">Submit</button>
                </div>        
            </form>
        </div>
        
    </div>
    <script src="<?=base_url();?>assets/script.js"></script>
</body>
</html>
