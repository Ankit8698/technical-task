<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- <link href='https://cdn.datatables.net/1.13.5/css/jquery.dataTables.min.css'>
    <link href='https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js'> -->
    <link href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css" rel="stylesheet">

    <title>Records</title>
</head>
<body>
    <div class="container mt-5 mb-5">
        <div>

            <h1 class="mb-3 text-center bg-light border border-1">Records</h1>
            
            <!-- Add the custom dropdown filter -->
            <div class='row'>
                <div class="form-group mb-3 col-md-4">
                    <label for="nameFilter">Search by Name:</label>
                </div>
                <div class='col-md-8 text-end'>
                <a href='<?=base_url()?>product' class='btn btn-info mt-3 text-white'>Back</a>
                </div>
            </div>
           
            <div class='border p-4 rounded bg-light'>
            <table id="recordsTable" class="table table-bordered p-3    ">
                <thead>
                    <tr class="table-dark">
                        <th scope="col">Sr.no</th>
                        <th scope="col">Name</th>
                        <th scope="col">Username</th>
                        <th scope="col">Phone number</th>
                        <th scope="col">Email Address</th>
                        <th scope="col">Password</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $count = 1;
                    foreach ($records as $record) { ?>
                        <tr>
                            <th scope="row"><?=$count++?></th>
                            <td><?=$record->name?></td>
                            <td><?=$record->username?></td>
                            <td><?=$record->mobile?></td>
                            <td><?=$record->email?></td>
                            <td><?=$record->password?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
            </div>
           
        </div>
    </div>

    <!-- jQuery and DataTables JavaScript -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>

    <script src="<?=base_url();?>assets/datatable.js"></script>
        <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
