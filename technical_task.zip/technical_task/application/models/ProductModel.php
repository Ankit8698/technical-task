<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProductModel extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function insert_user($data) {
        // Insert the user data into the 'users' table and return the inserted user ID
        $this->db->insert('users', $data);
        return $this->db->insert_id();
    }
    
    public function insert_product($data) {
        // Insert the product data into the 'products' table
        $this->db->insert('products', $data);
    }

    // Function to get all product data from the database
    public function get_all_products() {
        $query = $this->db->get('users');
        return $query->result();
    }

}
