<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('ProductModel');
    }

    public function index() {
        $this->load->view('product_form');
    }

    public function submit_form() {

            $this->load->view('product_form');
       
            $user_data = array(
                'name' => $this->input->post('name'),
                'username' => $this->input->post('username'),
                'mobile' => $this->input->post('mobile'),
                'email' => $this->input->post('email'),
                'password' => $this->input->post('password'),
            );
    
            // Insert the user data into the database and get the user ID
            $user_id = $this->ProductModel->insert_user($user_data);
    
            if ($user_id) {
                // Process the product data and save it to the database
                $product_names = $this->input->post('productName[]');
                $product_prices = $this->input->post('productPrice[]');
                $product_quantities = $this->input->post('productQuantity[]');
                $product_types = $this->input->post('productType[]');
                $product_discounts = $this->input->post('productDiscount[]');
                $finalAmount = $this->input->post('finalAmount');
    
                for ($i = 0; $i < count($product_names); $i++) {
                    $product_data = array(
                        'user_id' => $user_id,
                        'name' => $product_names[$i],
                        'price' => $product_prices[$i],
                        'quantity' => $product_quantities[$i],
                        'type' => $product_types[$i],
                        'discount' => $product_discounts[$i],
                        'finalAmount' => $finalAmount,
                    );
    
                    // Insert the product data into the database
                    $this->ProductModel->insert_product($product_data);
                }
    
                // Redirect to the success page after successful insertion
                redirect('Product/records ');
            } else {
                // If there was an error, show an error message or redirect to an error page
                echo "Error saving user data.";
            }

    }

    public function records (){
        $data['records'] = $this->ProductModel->get_all_products();
        $this->load->view('records',$data);
    }
}
