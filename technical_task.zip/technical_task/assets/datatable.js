$(document).ready(function() {
    // Initialize DataTables
    $('#recordsTable').DataTable();
});

////
$(document).ready(function() {
    // Initialize DataTables
    var table = $('#recordsTable').DataTable();

    // Create the custom dropdown filter for "name" column
    var nameFilter = $('<select id="nameFilter" class="form-control"><option value="">All</option></select>')
        .appendTo('.form-group')
        .on('change', function() {
            table.column(1).search($(this).val()).draw();
        });

    // Fetch unique names from the "name" column and populate the dropdown
    var uniqueNames = table.column(1).data().unique().sort().toArray();
    $.each(uniqueNames, function(index, value) {
        nameFilter.append('<option value="' + value + '">' + value + '</option>');
    });
});