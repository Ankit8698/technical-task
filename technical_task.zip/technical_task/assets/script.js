
    $(document).ready(function() {
        // Event delegation for dynamically added product type dropdowns
        $(document).on('change', 'select[name="productType[]"]', function() {
            const discountInput = $(this).closest('tr').find('input[name="productDiscount[]"]');
            if ($(this).val() === "flat") {
                discountInput.prop("readonly", true);
                discountInput.val("");
            } else if ($(this).val() === "discount") {
                discountInput.prop("readonly", false);
            }

            calculateFinalAmount();
        });

        // Event delegation for dynamically added product price and discount inputs
        $(document).on('input', 'input[name="productPrice[]"], input[name="productDiscount[]"]', function() {
            calculateFinalAmount();
        });
    });

    // calculate the final amount
   function calculateRowAmount(row) {
        const price = parseFloat(row.find('input[name="productPrice[]"]').val());
        const qty = parseFloat(row.find('input[name="productQuantity[]"]').val());
        const productType = row.find('select[name="productType[]"]').val();
        const discount = parseFloat(row.find('input[name="productDiscount[]"]').val());

        // Calculate the default discount when product type is "Flat"
        let defaultDiscount = (productType === 'flat') ? 0 : discount;

        // Calculate the total amount for the current row
        let rowAmount = isNaN(price) || isNaN(qty) ? 0 : (price * qty) - defaultDiscount;

        rowAmount = Math.max(rowAmount, 0);

        return rowAmount;
    }

    function calculateFinalAmount() {
        let totalAmount = 0;

        $('tbody tr').each(function() {
            let rowAmount = calculateRowAmount($(this));
            totalAmount += rowAmount;
        });

        // Set the final amount in the input field with ID "finalAmount"
        $('#finalAmount').val(totalAmount.toFixed(2));
    }

    $(document).ready(function() {
        // Calculate final amount on page load
        calculateFinalAmount();
            $('input[name="productPrice[]"], input[name="productQuantity[]"], select[name="productType[]"], input[name="productDiscount[]"]').on('input change', function() {
                calculateFinalAmount();
            });
            $('input[name="productQuantity[]"]').on('input', function() {
                calculateFinalAmount();
            });
    });

    // Add table row
    function addRow() {
        const newRow = `<tr>
                            <td><input type="text" class="form-control" name="productName[]" placeholder="Product name" required></td>
                            <td><input type="number" class="form-control" step="0.01" name="productPrice[]" placeholder="Product price" required></td>
                            <td><input type="number" class="form-control" name="productQuantity[]" placeholder="Product quantity" required></td>
                            <td>
                                <select class="form-control" name="productType[]" onchange="toggleDiscount(this)" required>
                                    <option selected disabled value="">Choose...</option>
                                    <option value="flat">Flat</option>
                                    <option value="discount">Discount</option>
                                </select>
                            </td>
                            <td><input type="text" class="form-control" name="productDiscount[]"  readonly ></td>
                            <td><button type="button" class="btn btn-danger" onclick="removeRow(this)">Remove</button></td>
                        </tr>`; 

        $("#productTable tbody").append(newRow);
    }

    function removeRow(button) {
        $(button).closest("tr").remove();
    }


//   <!--Bootstrap form validation -->

    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (function () {
    'use strict'

    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.querySelectorAll('.needs-validation')

    // Loop over them and prevent submission
    Array.prototype.slice.call(forms)
        .forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
            event.preventDefault()
            event.stopPropagation()
            }

            form.classList.add('was-validated')
        }, false)
        })
    })()
